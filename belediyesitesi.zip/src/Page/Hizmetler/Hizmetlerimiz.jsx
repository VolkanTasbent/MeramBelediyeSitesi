import React from 'react';

function Hizmetlerimiz() {
  return <div>Hizmetlerimiz</div>;
}

export default Hizmetlerimiz;
