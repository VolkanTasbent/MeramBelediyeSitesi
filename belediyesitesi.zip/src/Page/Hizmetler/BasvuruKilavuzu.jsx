import React from 'react';

function BasvuruKilavuzu() {
  return <div>BasvuruKilavuzu</div>;
}

export default BasvuruKilavuzu;
