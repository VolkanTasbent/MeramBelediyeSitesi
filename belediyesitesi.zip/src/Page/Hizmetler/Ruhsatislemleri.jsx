import React from 'react';

function Ruhsatislemleri() {
  return <div>Ruhsatislemleri</div>;
}

export default Ruhsatislemleri;
